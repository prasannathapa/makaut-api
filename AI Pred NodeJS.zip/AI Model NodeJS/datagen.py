import random

class Switch:
    def __init__(self, name, id) -> None:
        self.name = name
        self.id = id
        self.itemlist = []
        self.data = {}
    def setTempRel(self, name, threshold, errorMargin, precision):
        self.data[name+"_threshold"] = threshold
        self.data[name+"_errorMargin"] = errorMargin
        self.data[name+"_precision"] = precision
        self.itemlist.append(name)
    def prob(self, num, dem):
        return num >= random.randint(1, dem)
    def genOrd(self, name):
        threshold = self.data[name+"_threshold"]
        precision = self.data[name+"_precision"]         
        conv = 100
        if("poxymity" in name):
            conv = 1
        return threshold + random.triangular(0, precision*conv, precision*conv//2)/conv
    def genRand(self, name):
        threshold = self.data[name+"_threshold"]
        precision = self.data[name+"_precision"]
        conv = 100
        if("poxymity" in name):
            conv = 1
        return random.triangular(0,(threshold + precision)*conv, precision*conv//2)/conv
            
    def generate(self) -> str:
        op = self.name + ", "+str(self.id)+", "
        for iname in self.itemlist:
            em = self.data[iname+"_errorMargin"]
            if(self.prob(em, 500)):
                op += str(self.genRand(iname)) 
            else:
                op += str(self.genOrd(iname))
            op += ', '
        return op[0:-1]
f = open("data.csv","w+")
f.write("name, id, ontime,duration (mins),on_temperature,off_temperature,on_lumonicity,off_lumonicity,on_noise(db),off_noise(db),on_poxymity,off_poxymity\n")
sw = Switch("Fan",1)
sw.setTempRel("ontime",0,0,24)
sw.setTempRel("duration (mins)",20,20,660)
sw.setTempRel("on_temperature",30,8,22)
sw.setTempRel("off_temperature",12,8,22)
sw.setTempRel("on_lumonicity",0,0,10)
sw.setTempRel("off_lumonicity",0,0,10)
sw.setTempRel("on_noise (db)",29,10,120-29)
sw.setTempRel("off_noise (db)",12,10,100-12)
sw.setTempRel("on_poxymity",1,30,0)
sw.setTempRel("off_poxymity",0,0,1)
for i in range(736):
    f.write(sw.generate()+"\n")
sw = Switch("Light",2)
sw.setTempRel("ontime",12+6,12,24-12-6)
sw.setTempRel("duration (mins)",120,5,240)
sw.setTempRel("on_temperature",30,8,22)
sw.setTempRel("off_temperature",12,8,22)
sw.setTempRel("on_lumonicity",0,0,6)
sw.setTempRel("off_lumonicity",6,0,10)
sw.setTempRel("on_noise (db)",29,10,120-29)
sw.setTempRel("off_noise (db)",12,10,60)
sw.setTempRel("on_poxymity",1,70,0)
sw.setTempRel("off_poxymity",0,0,1)
for i in range(736):
    f.write(sw.generate()+"\n")




sw = Switch("Light",1)
sw = Switch("TV",1)
sw = Switch("Wall Socket",1)


